
import numpy as np

# Generate 100 random numbers between 0 and 1
data = np.random.random(100)

# Calculate statistics
print("For 100 Random Numbers")
print("----------------------")
print("Mean:", np.mean(data))
print("Minimum:", np.min(data))
print("Maximum:", np.max(data))
print("Standard Deviation:", np.std(data, ddof=1))


# Generate another 100 random numbers
data2 = np.random.random(100)

print("\nFor Another 100 Random Numbers")
print("--------------------------------")
print("Mean:", np.mean(data2))
print("Minimum:", np.min(data2))
print("Standard Deviation:", np.std(data2, ddof=1))


# Generate numbers using the same random seed
np.random.seed(42)
data3 = np.random.random(100)

np.random.seed(42)
data4 = np.random.random(100)

print("\nUsing Same Random Seed")
print("----------------------")
print("First Mean:", np.mean(data3))
print("Second Mean:", np.mean(data4))
print("Are arrays identical?", np.array_equal(data3, data4))


# Generate 10000 random numbers
data5 = np.random.random(10000)

print("\nFor 10000 Random Numbers")
print("------------------------")
print("Mean:", np.mean(data5))
print("Minimum:", np.min(data5))
print("Maximum:", np.max(data5))
print("Standard Deviation:", np.std(data5, ddof=1))
