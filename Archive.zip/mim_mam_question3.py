
import numpy as np
import matplotlib.pyplot as plt

# Reproducible random numbers
np.random.seed(42)

# Different sample sizes
sample_sizes = [100, 1000, 10000, 100000]

pi_estimates = []

# --------------------------------
# Monte Carlo Simulation
# --------------------------------

for N in sample_sizes:

    # Generate random x and y coordinates
    x = np.random.random(N)
    y = np.random.random(N)

    # Check whether points are inside quarter-circle
    inside = (x**2 + y**2) <= 1

    # Count points inside
    M = np.sum(inside)

    # Estimate pi
    pi_estimate = 4 * M / N

    pi_estimates.append(pi_estimate)

    print("Number of points:", N)
    print("Points inside:", M)
    print("Estimated PI:", pi_estimate)
    print("Actual PI:", np.pi)
    print("Error:", abs(np.pi - pi_estimate))
    print("--------------------------------")


# --------------------------------
# Plot Estimated PI vs Points
# --------------------------------

plt.figure(figsize=(9, 5))

plt.plot(
    sample_sizes,
    pi_estimates,
    marker='o',
    linewidth=2,
    label="Estimated PI"
)

# Actual value of pi
plt.axhline(
    y=np.pi,
    linestyle='--',
    label="Actual PI"
)

plt.xscale("log")

plt.xlabel("Number of Generated Points")
plt.ylabel("Estimated Value of PI")

plt.title("Monte Carlo Simulation: Estimation of PI")

plt.legend()
plt.grid(alpha=0.3)

plt.show()
