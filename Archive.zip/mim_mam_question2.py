
import numpy as np
import matplotlib.pyplot as plt

# Reproducible random numbers
np.random.seed(42)

N = 1000

# --------------------------------
# 1. Generate Inter-arrival Times
# --------------------------------

inter_arrival = np.random.exponential(
    scale=5,
    size=N
)

# --------------------------------
# 2. Generate Service Times
# --------------------------------

service_time = np.random.uniform(
    low=2,
    high=8,
    size=N
)

# --------------------------------
# 3. Calculate Sample Statistics
# --------------------------------

print("INTER-ARRIVAL TIME STATISTICS")
print("--------------------------------")
print("Sample Mean:", np.mean(inter_arrival))
print("Sample Standard Deviation:",
      np.std(inter_arrival, ddof=1))

print("\nSERVICE TIME STATISTICS")
print("--------------------------------")
print("Sample Mean:", np.mean(service_time))
print("Sample Standard Deviation:",
      np.std(service_time, ddof=1))


# --------------------------------
# 4. Theoretical Statistics
# --------------------------------

print("\nTHEORETICAL VALUES")
print("--------------------------------")

print("Inter-arrival Mean: 5")
print("Inter-arrival Standard Deviation: 5")

print("Service Mean:", (2 + 8) / 2)
print("Service Standard Deviation:",
      np.sqrt((8 - 2)**2 / 12))


# --------------------------------
# 5. Plot Both Histograms
# --------------------------------

plt.figure(figsize=(12, 5))

# Inter-arrival histogram
plt.subplot(1, 2, 1)

plt.hist(
    inter_arrival,
    bins=30,
    density=True,
    edgecolor="black"
)

plt.title("Exponential Distribution")
plt.xlabel("Inter-arrival Time (minutes)")
plt.ylabel("Probability Density")
plt.grid(alpha=0.3)


# Service time histogram
plt.subplot(1, 2, 2)

plt.hist(
    service_time,
    bins=30,
    density=True,
    edgecolor="black"
)

plt.title("Uniform Distribution")
plt.xlabel("Service Time (minutes)")
plt.ylabel("Probability Density")
plt.grid(alpha=0.3)


plt.tight_layout()
plt.show()
