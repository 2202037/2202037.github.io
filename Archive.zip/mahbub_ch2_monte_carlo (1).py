"""
MAHBUB SIR - CHAPTER 2: MONTE CARLO METHOD
Adaptable Python practical-exam templates for Examples 2.1 to 2.9.

Requirements:
    pip install numpy matplotlib

Run:
    python3 mahbub_ch2_monte_carlo.py

Choose an example from the menu. Change the clearly marked PARAMETERS
inside each function to match the numerical values in your exam question.

IMPORTANT:
These are general simulation templates based on the topic names supplied.
They are not claimed to reproduce every numerical detail of the textbook.
"""

import numpy as np
import matplotlib.pyplot as plt
from matplotlib.path import Path


# ================================================================
# EXAMPLE 2.1 - AREA OF AN IRREGULAR FIGURE
# Main idea: area = bounding-box area * (points inside / total points)
# ================================================================

def example_2_1():
    # PARAMETERS: replace polygon vertices with the figure in the question.
    polygon = np.array([
        [1, 1],
        [5, 1],
        [4, 4],
        [2, 5]
    ], dtype=float)

    N = 100_000  # number of random points

    xmin, ymin = polygon.min(axis=0)
    xmax, ymax = polygon.max(axis=0)

    # Generate random points uniformly in the bounding rectangle.
    x = np.random.uniform(xmin, xmax, N)
    y = np.random.uniform(ymin, ymax, N)
    points = np.column_stack((x, y))

    # True means the point is inside the polygon.
    inside = Path(polygon).contains_points(points)
    M = np.count_nonzero(inside)

    rectangle_area = (xmax - xmin) * (ymax - ymin)
    estimated_area = rectangle_area * M / N

    print("\nEXAMPLE 2.1 - IRREGULAR FIGURE AREA")
    print("Total points:", N)
    print("Points inside:", M)
    print("Bounding rectangle area:", rectangle_area)
    print("Estimated polygon area:", estimated_area)

    # Visualize a subset so the plot remains readable.
    shown = min(N, 6000)
    plt.figure(figsize=(7, 6))
    plt.scatter(x[:shown][inside[:shown]], y[:shown][inside[:shown]],
                s=5, label="Inside")
    plt.scatter(x[:shown][~inside[:shown]], y[:shown][~inside[:shown]],
                s=5, label="Outside")
    closed = np.vstack([polygon, polygon[0]])
    plt.plot(closed[:, 0], closed[:, 1], "k-", linewidth=2,
             label="Polygon boundary")
    plt.title("Monte Carlo Area Estimation")
    plt.xlabel("X")
    plt.ylabel("Y")
    plt.axis("equal")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.show()


# ================================================================
# EXAMPLE 2.2 - A GAMBLING GAME
# Main idea: simulate repeated fair coin tosses and track outcomes.
# Adapt the stopping rule and payoff to the exact question.
# This template stops when |heads - tails| reaches TARGET_DIFFERENCE.
# A player betting on heads wins if heads > tails at that moment.
# ================================================================

def example_2_2():
    # PARAMETERS
    NUMBER_OF_GAMES = 100
    TARGET_DIFFERENCE = 3
    COST_PER_TOSS = 1.0
    WIN_PRIZE = 5.0  # prize paid to the player if heads wins
    PROBABILITY_HEADS = 0.5

    toss_counts = []
    game_profits = []
    head_totals = []
    tail_totals = []

    for game in range(NUMBER_OF_GAMES):
        heads = 0
        tails = 0
        tosses = 0

        while abs(heads - tails) < TARGET_DIFFERENCE:
            tosses += 1
            if np.random.random() < PROBABILITY_HEADS:
                heads += 1
            else:
                tails += 1

        # Example payoff rule: player bets on heads.
        # Prize is received only if heads are ahead when the game stops.
        prize = WIN_PRIZE if heads > tails else 0.0
        total_cost = tosses * COST_PER_TOSS
        profit = prize - total_cost

        toss_counts.append(tosses)
        game_profits.append(profit)
        head_totals.append(heads)
        tail_totals.append(tails)

    print("\nEXAMPLE 2.2 - GAMBLING GAME")
    print("Number of games:", NUMBER_OF_GAMES)
    print("Average tosses per game:", np.mean(toss_counts))
    print("Total heads:", sum(head_totals))
    print("Total tails:", sum(tail_totals))
    print("Total profit/loss:", sum(game_profits))
    print("Average profit/loss per game:", np.mean(game_profits))
    print("Games with positive profit:", np.sum(np.array(game_profits) > 0))

    plt.figure(figsize=(8, 4))
    plt.hist(game_profits, bins=15, edgecolor="black")
    plt.title("Profit/Loss per Gambling Game")
    plt.xlabel("Profit / Loss")
    plt.ylabel("Number of games")
    plt.grid(axis="y", alpha=0.3)
    plt.show()


# ================================================================
# EXAMPLE 2.3 - NUMERICAL INTEGRATION BY MONTE CARLO
# Main idea: integral from a to b of f(x) dx ~= (b-a)*average(f(X)).
# This mean-value estimator also works when f has negative values.
# ================================================================

def example_2_3():
    # PARAMETERS: change function and limits to match the question.
    a = 0.0
    b = 1.0
    N = 100_000

    def f(x):
        return x ** 3

    x = np.random.uniform(a, b, N)
    y = f(x)

    estimated_integral = (b - a) * np.mean(y)

    # Exact answer is supplied here only for this demonstration f(x)=x^3.
    exact_integral = (b ** 4 - a ** 4) / 4

    print("\nEXAMPLE 2.3 - MONTE CARLO INTEGRATION")
    print("Number of samples:", N)
    print("Estimated integral:", estimated_integral)
    print("Exact integral for x^3:", exact_integral)
    print("Absolute error:", abs(estimated_integral - exact_integral))

    x_plot = np.linspace(a, b, 400)
    plt.figure(figsize=(8, 5))
    plt.plot(x_plot, f(x_plot), label="f(x) = x^3")
    plt.fill_between(x_plot, f(x_plot), alpha=0.2)
    plt.title("Area Under the Curve")
    plt.xlabel("x")
    plt.ylabel("f(x)")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.show()


# ================================================================
# EXAMPLE 2.4 - DETERMINATION OF VALUE OF PI
# Main idea: pi ~= 4 * (points inside quarter-circle / total points).
# ================================================================

def example_2_4():
    # PARAMETERS
    sample_sizes = [100, 1_000, 10_000, 100_000]
    estimates = []

    print("\nEXAMPLE 2.4 - ESTIMATION OF PI")

    for N in sample_sizes:
        x = np.random.uniform(0, 1, N)
        y = np.random.uniform(0, 1, N)

        inside = (x ** 2 + y ** 2) <= 1
        M = np.count_nonzero(inside)
        pi_estimate = 4 * M / N
        estimates.append(pi_estimate)

        print(f"N = {N:>7}, inside = {M:>7}, "
              f"estimated pi = {pi_estimate:.8f}, "
              f"error = {abs(np.pi - pi_estimate):.8f}")

    plt.figure(figsize=(8, 5))
    plt.plot(sample_sizes, estimates, marker="o", label="Estimated pi")
    plt.axhline(np.pi, linestyle="--", label="Actual pi")
    plt.xscale("log")
    plt.xlabel("Number of random points")
    plt.ylabel("Estimated value of pi")
    plt.title("Monte Carlo Estimation of Pi")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.show()


# ================================================================
# EXAMPLE 2.5 - RANDOM WALK / DRUNKARD'S WALK
# Main idea: choose a random direction at each step and update x,y.
# Probabilities and step lengths can be changed in PARAMETERS.
# ================================================================

def example_2_5():
    # PARAMETERS
    NUMBER_OF_STEPS = 500
    directions = ["North", "South", "East", "West"]
    probabilities = [0.25, 0.25, 0.25, 0.25]
    step_lengths = {"North": 1, "South": 1, "East": 1, "West": 1}

    x = 0.0
    y = 0.0
    x_history = [x]
    y_history = [y]
    total_distance = 0.0

    for _ in range(NUMBER_OF_STEPS):
        direction = np.random.choice(directions, p=probabilities)
        distance = step_lengths[direction]
        total_distance += distance

        if direction == "North":
            y += distance
        elif direction == "South":
            y -= distance
        elif direction == "East":
            x += distance
        elif direction == "West":
            x -= distance

        x_history.append(x)
        y_history.append(y)

    final_distance = np.sqrt(x ** 2 + y ** 2)
 
    print("\nEXAMPLE 2.5 - RANDOM WALK")
    print("Number of steps:", NUMBER_OF_STEPS)
    print("Final X position:", x)
    print("Final Y position:", y)
    print("Distance from starting point:", final_distance)
    print("Total path length:", total_distance)

    plt.figure(figsize=(7, 6))
    plt.plot(x_history, y_history, marker=".", markersize=3)
    plt.scatter([0, x], [0, y], s=70, label="Start / End")
    plt.title("Two-Dimensional Random Walk")
    plt.xlabel("X position")
    plt.ylabel("Y position")
    plt.axis("equal")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.show()


# ================================================================
# EXAMPLE 2.6 - RELIABILITY / BEARING MAINTENANCE
# General comparison:
# Policy A: replace a bearing only after it fails (corrective).
# Policy B: replace it preventively at a fixed age if it survives.
# Model assumptions and distributions are parameters to be changed.
# ================================================================

def simulate_bearing_policy(horizon, policy, preventive_age,
                            life_scale, repair_mean,
                            failure_cost, preventive_cost,
                            downtime_cost_per_hour, rng):
    time = 0.0
    total_cost = 0.0
    failures = 0
    preventive_replacements = 0
    up_time = 0.0
    down_time = 0.0

    while time < horizon:
        life = rng.exponential(life_scale)

        if policy == "preventive" and life >= preventive_age:
            operating_time = preventive_age
            event = "preventive"
        else:
            operating_time = life
            event = "failure"

        remaining = horizon - time
        operating_time = min(operating_time, remaining)
        up_time += operating_time
        time += operating_time

        if time >= horizon:
            break

        if event == "failure":
            failures += 1
            repair_time = rng.exponential(repair_mean)
            total_cost += failure_cost
        else:
            preventive_replacements += 1
            repair_time = 0.0
            total_cost += preventive_cost

        actual_downtime = min(repair_time, horizon - time)
        down_time += actual_downtime
        total_cost += actual_downtime * downtime_cost_per_hour
        time += actual_downtime

    return total_cost, failures, preventive_replacements, up_time, down_time


def example_2_6():
    # PARAMETERS: illustrative assumptions, not textbook-specific values.
    HORIZON = 10_000.0
    NUMBER_OF_REPLICATIONS = 500
    PREVENTIVE_AGE = 500.0
    MEAN_BEARING_LIFE = 700.0
    MEAN_REPAIR_TIME = 8.0
    FAILURE_COST = 100.0
    PREVENTIVE_COST = 45.0
    DOWNTIME_COST_PER_HOUR = 10.0

    rng = np.random.default_rng()
    results = {"corrective": [], "preventive": []}

    for _ in range(NUMBER_OF_REPLICATIONS):
        for policy in results:
            result = simulate_bearing_policy(
                HORIZON, policy, PREVENTIVE_AGE,
                MEAN_BEARING_LIFE, MEAN_REPAIR_TIME,
                FAILURE_COST, PREVENTIVE_COST,
                DOWNTIME_COST_PER_HOUR, rng
            )
            results[policy].append(result)

    print("\nEXAMPLE 2.6 - BEARING RELIABILITY")
    for policy, values in results.items():
        values = np.array(values, dtype=float)
        print(f"\nPolicy: {policy}")
        print("Average total cost:", np.mean(values[:, 0]))
        print("Average failures:", np.mean(values[:, 1]))
        print("Average preventive replacements:", np.mean(values[:, 2]))
        print("Average downtime:", np.mean(values[:, 4]))

    avg_costs = [np.mean(np.array(results[p])[:, 0])
                 for p in ("corrective", "preventive")]
    plt.figure(figsize=(7, 4))
    plt.bar(["Corrective", "Preventive"], avg_costs)
    plt.ylabel("Average total cost")
    plt.title("Comparison of Bearing Maintenance Policies")
    plt.grid(axis="y", alpha=0.3)
    plt.show()


# ================================================================
# EXAMPLE 2.7 - APPLICATION OF RANDOM NORMAL NUMBERS / BOMB IMPACT
# Main idea: impact coordinates follow normal distributions.
# A hit occurs if impact lies inside the target region.
# This example uses a circular target.
# ================================================================

def example_2_7():
    # PARAMETERS
    N = 100_000
    TARGET_CENTER_X = 0.0
    TARGET_CENTER_Y = 0.0
    TARGET_RADIUS = 10.0
    IMPACT_MEAN_X = 1.0
    IMPACT_MEAN_Y = -1.0
    IMPACT_SD_X = 5.0
    IMPACT_SD_Y = 4.0

    impact_x = np.random.normal(IMPACT_MEAN_X, IMPACT_SD_X, N)
    impact_y = np.random.normal(IMPACT_MEAN_Y, IMPACT_SD_Y, N)

    distance_squared = ((impact_x - TARGET_CENTER_X) ** 2
                        + (impact_y - TARGET_CENTER_Y) ** 2)
    hits = distance_squared <= TARGET_RADIUS ** 2
    hit_count = np.count_nonzero(hits)
    hit_percentage = 100 * hit_count / N

    print("\nEXAMPLE 2.7 - NORMAL BOMB IMPACT")
    print("Total impacts:", N)
    print("Hits:", hit_count)
    print("Misses:", N - hit_count)
    print("Hit percentage:", hit_percentage, "%")

    shown = min(N, 5000)
    theta = np.linspace(0, 2 * np.pi, 300)
    plt.figure(figsize=(7, 6))
    plt.scatter(impact_x[:shown], impact_y[:shown], s=5, alpha=0.4)
    plt.plot(TARGET_CENTER_X + TARGET_RADIUS * np.cos(theta),
             TARGET_CENTER_Y + TARGET_RADIUS * np.sin(theta),
             linewidth=2, label="Target boundary")
    plt.title("Normally Distributed Bomb Impact Locations")
    plt.xlabel("Impact X")
    plt.ylabel("Impact Y")
    plt.axis("equal")
    plt.legend()
    plt.grid(alpha=0.3)
    plt.show()


# ================================================================
# EXAMPLE 2.8 - A HINGE ASSEMBLY
# General tolerance-stack model:
# clearance = hole diameter - pin diameter.
# Assembly succeeds if minimum_clearance <= clearance <= maximum_clearance.
# Change dimensions and tolerances to match the exam statement.
# ================================================================

def example_2_8():
    # PARAMETERS: dimensions are illustrative.
    N = 100_000
    HOLE_NOMINAL = 10.0
    HOLE_TOLERANCE = 0.10
    PIN_NOMINAL = 9.8
    PIN_TOLERANCE = 0.08
    MINIMUM_CLEARANCE = 0.05
    MAXIMUM_CLEARANCE = 0.30

    hole = np.random.uniform(
        HOLE_NOMINAL - HOLE_TOLERANCE,
        HOLE_NOMINAL + HOLE_TOLERANCE,
        N
    )
    pin = np.random.uniform(
        PIN_NOMINAL - PIN_TOLERANCE,
        PIN_NOMINAL + PIN_TOLERANCE,
        N
    )

    clearance = hole - pin
    success = ((clearance >= MINIMUM_CLEARANCE)
               & (clearance <= MAXIMUM_CLEARANCE))

    successful = np.count_nonzero(success)
    failed = N - successful
    failure_probability = failed / N

    print("\nEXAMPLE 2.8 - HINGE ASSEMBLY")
    print("Total assemblies:", N)
    print("Successful assemblies:", successful)
    print("Failed assemblies:", failed)
    print("Estimated failure probability:", failure_probability)
    print("Estimated failure percentage:", 100 * failure_probability, "%")
    print("Mean clearance:", np.mean(clearance))
    print("Minimum clearance observed:", np.min(clearance))
    print("Maximum clearance observed:", np.max(clearance))

    plt.figure(figsize=(8, 4))
    plt.hist(clearance, bins=40, edgecolor="black")
    plt.axvline(MINIMUM_CLEARANCE, linestyle="--",
                label="Minimum allowed clearance")
    plt.axvline(MAXIMUM_CLEARANCE, linestyle="--",
                label="Maximum allowed clearance")
    plt.title("Hinge Assembly Clearance Distribution")
    plt.xlabel("Clearance")
    plt.ylabel("Frequency")
    plt.legend()
    plt.grid(alpha=0.2)
    plt.show()


# ================================================================
# EXAMPLE 2.9 - MAINTENANCE COST OF FOUR TUBES
# General model: four independent tubes operate in parallel.
# A tube failure causes replacement time and cost. The system is down
# only when all four tubes are unavailable. Change this structure if
# the question describes series operation, standby tubes, or another rule.
# ================================================================

def example_2_9():
    # PARAMETERS: illustrative assumptions.
    NUMBER_OF_TUBES = 4
    SIMULATION_HORIZON = 5_000.0
    MEAN_TUBE_LIFE = 1_000.0
    MEAN_REPLACEMENT_TIME = 5.0
    REPLACEMENT_COST_PER_TUBE = 50.0
    SYSTEM_DOWNTIME_COST_PER_HOUR = 100.0

    rng = np.random.default_rng()

    # Each tube has its own next-failure time and repair completion time.
    next_failure = rng.exponential(MEAN_TUBE_LIFE, NUMBER_OF_TUBES)
    repair_completion = np.full(NUMBER_OF_TUBES, np.inf)
    tube_working = np.ones(NUMBER_OF_TUBES, dtype=bool)

    current_time = 0.0
    total_replacement_cost = 0.0
    system_downtime = 0.0
    failures = 0
    system_was_down = False
    down_start = None

    while current_time < SIMULATION_HORIZON:
        next_failure_time = np.where(tube_working, next_failure, np.inf)
        next_event_time = min(np.min(next_failure_time),
                              np.min(repair_completion))

        if not np.isfinite(next_event_time) or next_event_time >= SIMULATION_HORIZON:
            break

        # If all tubes are down during this interval, accumulate downtime.
        if not np.any(tube_working):
            system_downtime += next_event_time - current_time

        current_time = next_event_time

        # Process all tube failures occurring at this time.
        failed_indices = np.where(
            tube_working & np.isclose(next_failure, current_time)
        )[0]

        for i in failed_indices:
            tube_working[i] = False
            failures += 1
            total_replacement_cost += REPLACEMENT_COST_PER_TUBE
            repair_completion[i] = (
                current_time + rng.exponential(MEAN_REPLACEMENT_TIME)
            )

        # Process all replacement completions occurring at this time.
        repaired_indices = np.where(
            np.isclose(repair_completion, current_time)
        )[0]

        for i in repaired_indices:
            tube_working[i] = True
            repair_completion[i] = np.inf
            next_failure[i] = (
                current_time + rng.exponential(MEAN_TUBE_LIFE)
            )

    # Account for the final interval if all tubes are down at horizon.
    if not np.any(tube_working):
        system_downtime += SIMULATION_HORIZON - current_time

    downtime_cost = system_downtime * SYSTEM_DOWNTIME_COST_PER_HOUR
    total_cost = total_replacement_cost + downtime_cost

    print("\nEXAMPLE 2.9 - FOUR-TUBE MAINTENANCE")
    print("Number of tubes:", NUMBER_OF_TUBES)
    print("Simulation horizon:", SIMULATION_HORIZON)
    print("Total tube failures:", failures)
    print("System downtime:", system_downtime)
    print("Replacement cost:", total_replacement_cost)
    print("Downtime cost:", downtime_cost)
    print("Total maintenance cost:", total_cost)


# ================================================================
# MAIN MENU
# ================================================================

def main():
    np.random.seed(42)

    examples = {
        "1": example_2_1,
        "2": example_2_2,
        "3": example_2_3,
        "4": example_2_4,
        "5": example_2_5,
        "6": example_2_6,
        "7": example_2_7,
        "8": example_2_8,
        "9": example_2_9,
    }

    print("=" * 60)
    print("MAHBUB SIR - CHAPTER 2: MONTE CARLO SIMULATION")
    print("=" * 60)
    print("1. Area of an Irregular Figure")
    print("2. A Gambling Game")
    print("3. Numerical Integration")
    print("4. Determination of Value of PI")
    print("5. Random Walk")
    print("6. Reliability / Bearing Maintenance")
    print("7. Normal Random Numbers / Bomb Impact")
    print("8. Hinge Assembly")
    print("9. Maintenance Cost of Four Tubes")
    print("0. Exit")

    choice = input("\nChoose an example (0-9): ").strip()

    if choice == "0":
        print("Exiting.")
    elif choice in examples:
        examples[choice]()
    else:
        print("Invalid choice. Run the program again and choose 0-9.")


if __name__ == "__main__":
    main()
